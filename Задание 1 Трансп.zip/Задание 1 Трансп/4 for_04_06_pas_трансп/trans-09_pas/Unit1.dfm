object Form1: TForm1
  Left = 224
  Top = 119
  Width = 428
  Height = 439
  Caption = #1058#1088#1072#1085#1089#1087#1086#1088#1090#1085#1072#1103' '#1079#1072#1076#1072#1095#1072
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Label2: TLabel
    Left = 64
    Top = 64
    Width = 82
    Height = 13
    Caption = #1055#1054#1058#1056#1045#1041#1048#1058#1045#1051#1048
  end
  object Label3: TLabel
    Left = 248
    Top = 80
    Width = 82
    Height = 13
    Caption = #1055#1054#1058#1056#1045#1041#1048#1058#1045#1051#1048
  end
  object Label4: TLabel
    Left = 16
    Top = 8
    Width = 365
    Height = 20
    Caption = #1052#1077#1090#1086#1076' '#1084#1080#1085#1080#1084#1072#1083#1100#1085#1086#1075#1086' '#1101#1083#1077#1084#1077#1085#1090#1072' '#1074' '#1084#1072#1090#1088#1080#1094#1077
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clRed
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object gr1: TStringGrid
    Left = 44
    Top = 92
    Width = 133
    Height = 121
    DefaultColWidth = 24
    DefaultRowHeight = 18
    RowCount = 6
    TabOrder = 0
  end
  object gr2: TStringGrid
    Left = 220
    Top = 92
    Width = 133
    Height = 121
    DefaultColWidth = 24
    DefaultRowHeight = 18
    RowCount = 6
    TabOrder = 1
  end
  object Button1: TButton
    Left = 148
    Top = 32
    Width = 101
    Height = 25
    Caption = #1056#1077#1096#1072#1077#1084
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 2
    OnClick = Button1Click
  end
  object Memo1: TMemo
    Left = 48
    Top = 240
    Width = 313
    Height = 129
    TabOrder = 3
  end
  object grB: TStringGrid
    Left = 44
    Top = 76
    Width = 133
    Height = 21
    DefaultColWidth = 24
    DefaultRowHeight = 18
    FixedCols = 0
    RowCount = 1
    FixedRows = 0
    TabOrder = 4
  end
  object grA: TStringGrid
    Left = 14
    Top = 92
    Width = 27
    Height = 141
    ColCount = 1
    DefaultColWidth = 24
    DefaultRowHeight = 18
    FixedCols = 0
    RowCount = 6
    FixedRows = 0
    TabOrder = 5
  end
  object Button2: TButton
    Left = 16
    Top = 32
    Width = 105
    Height = 25
    Caption = #1048#1085#1080#1094#1080#1072#1083#1080#1079#1072#1094#1080#1103' '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 6
    OnClick = Button2Click
  end
end
