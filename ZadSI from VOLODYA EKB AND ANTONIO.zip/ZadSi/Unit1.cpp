//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
    randomize();
    clickCounter = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::JumpButton()
{
    int margin = 10;

    int maxLeft = ClientWidth - Button1->Width - margin;
    if (maxLeft < margin) maxLeft = margin;
    int maxTop = ClientHeight - Button1->Height - margin;
    if (maxTop < margin) maxTop = margin;

    Button1->Left = random(maxLeft - margin + 1) + margin;
    Button1->Top  = random(maxTop - margin + 1) + margin;

    int newWidth = random(150) + 60;
    int newHeight = random(80) + 30;

    if (Button1->Left + newWidth > ClientWidth - margin)
        newWidth = ClientWidth - Button1->Left - margin;
    if (Button1->Top + newHeight > ClientHeight - margin)
        newHeight = ClientHeight - Button1->Top - margin;

    Button1->Width = newWidth;
    Button1->Height = newHeight;

    Button1->BringToFront();
    Button1->Invalidate();
    Application->ProcessMessages();
    Sleep(100);
}
//---------------------------------------------------------------------------
bool __fastcall TForm1::dormin()
{
    bool bmin = false;

    for (int i = 1; i <= howpost; i++)
    {
        for (int j = 1; j <= howport; j++)
        {
            if ((acol[j] > 0) && (arow[i] > 0))
            {
                if ((!bmin) && (a2[i][j] > 0))
                {
                    minVal = a2[i][j];
                    imin = i;
                    jmin = j;
                    bmin = true;
                }
                if (bmin && (a2[i][j] < minVal) && (a2[i][j] > 0))
                {
                    minVal = a2[i][j];
                    imin = i;
                    jmin = j;
                }
            }
        }
    }
    return bmin;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::arrInit()
{
    acol[1] = 45;
    acol[2] = 55;
    acol[3] = 51;
    acol[4] = 49;

    arow[1] = 20;
    arow[2] = 30;
    arow[3] = 40;
    arow[4] = 50;
    arow[5] = 60;

    a2[1][1] = 10; a2[1][2] = 1; a2[1][3] = 2; a2[1][4] = 8;
    a2[2][1] = 8;  a2[2][2] = 3; a2[2][3] = 1; a2[2][4] = 1;
    a2[3][1] = 6;  a2[3][2] = 5; a2[3][3] = 6; a2[3][4] = 4;
    a2[4][1] = 4;  a2[4][2] = 7; a2[4][3] = 9; a2[4][4] = 6;
    a2[5][1] = 3;  a2[5][2] = 4; a2[5][3] = 2; a2[5][4] = 8;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::grView(TStringGrid *gr, int col, int row)
{
    gr->ColCount = col;
    gr->RowCount = row;

    for (int i = 1; i <= gr->ColCount - 1; i++)
    {
        gr->Cells[i][0] = IntToStr(acol[i]);
    }

    for (int i = 1; i <= gr->RowCount - 1; i++)
    {
        gr->Cells[0][i] = IntToStr(arow[i]);
    }

    for (int i = 1; i <= howpost; i++)
    {
        for (int j = 1; j <= howport; j++)
        {
            gr->Cells[j][i] = IntToStr(a2[i][j]);
        }
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::GoMin()
{
    int how;

    if ((imin > 0) && (jmin > 0) && (minVal > 0))
    {
        how = arow[imin];

        if (acol[jmin] == arow[imin])
        {
            arow[imin] = 0;
            acol[jmin] = 0;
        }
        else if (acol[jmin] < arow[imin])
        {
            how = acol[jmin];
            arow[imin] = arow[imin] - acol[jmin];
            acol[jmin] = 0;
        }
        else
        {
            acol[jmin] = acol[jmin] - arow[imin];
            arow[imin] = 0;
        }

        Memo1->Lines->Add(AnsiString("Supplier A") + IntToStr(imin) + AnsiString(" -> ")
            + AnsiString("Consumer B") + IntToStr(jmin)
            + AnsiString(" : ") + IntToStr(how) + AnsiString(" (cost: ") + IntToStr(a2[imin][jmin]) + AnsiString(")"));

        a2[imin][jmin] = 0;
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
    if (clickCounter < 3)
    {
        JumpButton();
        clickCounter++;
        return; // ��� ���������
    }

    while (dormin())
    {
        GoMin();
        grView(gr2, howport + 1, howpost + 1);
        ShowMessage("Continue");
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
    clickCounter = 0;

    howport = 4;
    howpost = 5;

    for (int i = 1; i <= howport; i++)
    {
        grB->Cells[i][0] = "B" + IntToStr(i);
    }

    for (int i = 1; i <= howpost; i++)
    {
        grA->Cells[0][i] = "A" + IntToStr(i);
    }

    arrInit();
    grView(gr1, howport + 1, howpost + 1);

    // ���������� ������ � �������� ��������� (��������� ���� ��������)
    Button1->Left = 8;
    Button1->Top  = 8;
    Button1->Width  = 75;
    Button1->Height = 25;
}
//---------------------------------------------------------------------------
