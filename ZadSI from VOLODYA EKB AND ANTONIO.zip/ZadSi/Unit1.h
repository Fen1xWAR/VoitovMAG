//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:    // IDE-managed Components
    TStringGrid *gr1;
    TStringGrid *gr2;
    TButton *Button1;
    TMemo *Memo1;
    TLabel *Label2;
    TLabel *Label3;
    TStringGrid *grB;
    TStringGrid *grA;
    TLabel *Label4;
    TButton *Button2;
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall Button2Click(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
private:
    // Arrays
    int acol[31];   // Consumers and their demand
    int arow[31];   // Suppliers and their capacity
    int a2[31][31]; // Transport cost array
    int howport;    // Number of consumers
    int howpost;    // Number of suppliers
    int minVal;     // Selected MIN value
    int imin;
    int jmin;       // Coordinates of min value

    int clickCounter; // ������� �������

    bool __fastcall dormin();
    void __fastcall arrInit();
    void __fastcall grView(TStringGrid *gr, int col, int row);
    void __fastcall GoMin();
    void __fastcall JumpButton(); // ����� ��� ������ ������

public:
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
