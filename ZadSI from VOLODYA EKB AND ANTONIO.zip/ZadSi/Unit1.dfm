object Form1: TForm1
  Left = 308
  Top = 207
  Width = 1142
  Height = 740
  Caption = 'Form1'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 640
    Top = 24
    Width = 293
    Height = 49
    Caption = #1052#1077#1090#1086#1076' '#1084#1080#1085#1080#1084#1072#1083#1100#1085#1086#1075#1086' '#1101#1083#1077#1084#1077#1085#1090#1072'  '#1084#1072#1090#1088#1080#1094#1099
  end
  object Label2: TLabel
    Left = 720
    Top = 120
    Width = 32
    Height = 13
    Caption = 'Label2'
  end
  object Label3: TLabel
    Left = 824
    Top = 88
    Width = 32
    Height = 13
    Caption = 'Label3'
  end
  object Label4: TLabel
    Left = 848
    Top = 136
    Width = 32
    Height = 13
    Caption = 'Label4'
  end
  object Button1: TButton
    Left = 368
    Top = 72
    Width = 145
    Height = 49
    Caption = #1056#1077#1096#1077#1085#1080#1077
    TabOrder = 0
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 160
    Top = 80
    Width = 161
    Height = 49
    Caption = #1048#1085#1080#1094#1080#1072#1083#1080#1079#1072#1094#1080#1103
    TabOrder = 1
    OnClick = Button2Click
  end
  object gr1: TStringGrid
    Left = 72
    Top = 160
    Width = 353
    Height = 177
    TabOrder = 2
  end
  object gr2: TStringGrid
    Left = 600
    Top = 192
    Width = 361
    Height = 169
    TabOrder = 3
  end
  object Memo1: TMemo
    Left = 72
    Top = 360
    Width = 921
    Height = 249
    Lines.Strings = (
      'Memo1')
    TabOrder = 4
  end
  object grA: TStringGrid
    Left = 96
    Top = 192
    Width = 320
    Height = 120
    TabOrder = 5
    Visible = False
    ColWidths = (
      64
      64
      64
      64
      64)
  end
  object StringGrid4: TStringGrid
    Left = 1056
    Top = 224
    Width = 25
    Height = 57
    TabOrder = 6
  end
  object grB: TStringGrid
    Left = 632
    Top = 224
    Width = 320
    Height = 120
    TabOrder = 7
    Visible = False
  end
end
